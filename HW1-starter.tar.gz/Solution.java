package p0;


class Solution {

    public int  recursiveTernarySearch(int array[], int key) {

	// TODO: Implement this function    
        return -1;
    }
    
    public int iterativeTernarySearch(int array[], int key) {
    
        // TODO: Implement this function    
        return -1;
        
    }
 

    public boolean anagramCheck(String str1, String str2)
    {
       // TODO: Implement this function    
        return -1;
    }   
    
    
    public int countSwapsInInsertionSort(int array[])
    {
	// TODO: Implement this function    
        return -1;
    }
    
}
